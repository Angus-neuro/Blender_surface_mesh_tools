# Init.py

bl_info = {
    "name": "Layer Tools Suite (NIfTI Paint, Vertex Select, HipSTA)",
    "author": "",
    "version": (1, 3, 0),
    "blender": (2, 93, 0),
    "location": "3D Viewport > Sidebar (N)",
    "description": "Split tabs: NIfTI painting, Vertex selection+ROIs+Peaks, and HipSTA surface/thickness visualisation.",
    "category": "Mesh",
}

# ---------------- Dependency bootstrap (local 'pydeps') ----------------

import os, sys, importlib, subprocess, shutil

# Blender API (loaded lazily by Blender, safe to import here)
import bpy
from bpy.types import AddonPreferences, Operator

# Add-on dir + local deps path
_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_DEP_DIR   = os.path.join(_ADDON_DIR, "pydeps")


# -------------------------------------------------------------------
# Protect Blender's bundled NumPy
# -------------------------------------------------------------------
#
# Blender already ships a complete, ABI-compatible NumPy build. Installing
# nibabel into a local --target directory with normal dependency resolution can
# place another NumPy package inside pydeps. Because pydeps is inserted at the
# front of sys.path, that local package can shadow Blender's NumPy and produce
# errors such as:
#
#     ModuleNotFoundError: No module named 'numpy.ma'
#
# or binary/ABI import failures.
#
# The add-on therefore:
#   1. temporarily removes pydeps from sys.path;
#   2. removes any local numpy/numpy.libs/numpy-*.dist-info shadow copies;
#   3. clears an already-loaded NumPy only when it came from this pydeps folder;
#   4. imports and validates Blender's own numpy and numpy.ma;
#   5. inserts pydeps only after NumPy is safely loaded.
#
# nibabel is installed with --no-deps below, so pip cannot reintroduce a local
# NumPy copy.

def _path_is_inside(path_value, parent_value):
    """Return True when path_value is located inside parent_value."""
    if not path_value:
        return False

    try:
        path_abs = os.path.normcase(os.path.abspath(path_value))
        parent_abs = os.path.normcase(os.path.abspath(parent_value))
        return os.path.commonpath([path_abs, parent_abs]) == parent_abs
    except Exception:
        return False


def _remove_path_from_sys_path(path_value):
    """Remove every normalized occurrence of path_value from sys.path."""
    target = os.path.normcase(os.path.abspath(path_value))

    kept = []

    for entry in sys.path:
        try:
            same = os.path.normcase(os.path.abspath(entry)) == target
        except Exception:
            same = False

        if not same:
            kept.append(entry)

    sys.path[:] = kept


def _remove_local_numpy_shadow():
    """
    Delete NumPy packages accidentally installed into this add-on's pydeps.

    Returns a list of removed paths. Failure to remove one path is tolerated so
    the add-on can still present a useful error message.
    """
    removed = []

    if not os.path.isdir(_DEP_DIR):
        return removed

    names = os.listdir(_DEP_DIR)

    for name in names:
        lower = name.lower()

        is_numpy_shadow = (
            lower == "numpy"
            or lower == "numpy.libs"
            or lower.startswith("numpy-") and lower.endswith(".dist-info")
            or lower.startswith("numpy-") and lower.endswith(".egg-info")
            or lower.startswith("numpy-") and lower.endswith(".data")
        )

        if not is_numpy_shadow:
            continue

        path = os.path.join(_DEP_DIR, name)

        try:
            if os.path.isdir(path) and not os.path.islink(path):
                shutil.rmtree(path, ignore_errors=False)
            else:
                os.remove(path)

            removed.append(path)

        except Exception:
            # A locked file on Windows may require a Blender restart. The
            # validation below will still detect whether the wrong NumPy wins.
            pass

    return removed


def _clear_loaded_local_numpy():
    """
    Remove NumPy modules from sys.modules only when their files came from pydeps.

    This mainly helps after disabling/re-enabling an older add-on version in the
    same Blender session. A full Blender restart remains the safest recovery
    after replacing the add-on.
    """
    root = sys.modules.get("numpy")

    root_file = getattr(root, "__file__", "") if root is not None else ""

    if not _path_is_inside(root_file, _DEP_DIR):
        return False

    for module_name in list(sys.modules):
        if module_name == "numpy" or module_name.startswith("numpy."):
            sys.modules.pop(module_name, None)

    return True


# Remove a stale pydeps entry before validating Blender's own NumPy.
_remove_path_from_sys_path(_DEP_DIR)

_REMOVED_LOCAL_NUMPY = _remove_local_numpy_shadow()
_CLEARED_LOCAL_NUMPY = _clear_loaded_local_numpy()

try:
    import numpy as _blender_numpy
    import numpy.ma as _blender_numpy_ma
except Exception as exc:
    raise RuntimeError(
        "Layer Tools Suite could not load Blender's bundled NumPy, including "
        "numpy.ma. Close Blender completely, delete the add-on's 'pydeps/numpy' "
        "and 'pydeps/numpy.libs' folders if they still exist, then restart "
        "Blender and enable the add-on again."
    ) from exc

_NUMPY_ORIGIN = os.path.abspath(
    getattr(_blender_numpy, "__file__", "")
)

if _path_is_inside(_NUMPY_ORIGIN, _DEP_DIR):
    raise RuntimeError(
        "Layer Tools Suite is still loading NumPy from the add-on's pydeps "
        f"directory instead of Blender's bundled Python:\n{_NUMPY_ORIGIN}\n\n"
        "Close Blender completely, remove all numpy* entries from the pydeps "
        "folder, and restart Blender."
    )

# Make local pure-Python dependencies importable only after Blender's NumPy has
# been loaded and validated.
if os.path.isdir(_DEP_DIR) and _DEP_DIR not in sys.path:
    sys.path.insert(0, _DEP_DIR)


_REQUIRED_PY_DEPS = [
    # Blender supplies NumPy. Do not add NumPy to this list.
    #
    # The installer uses --no-deps to prevent pip from placing another NumPy
    # build in pydeps. Nibabel's required pure-Python packaging dependency is
    # therefore listed explicitly.
    "packaging>=20",
    "nibabel>=5.0.0,<5.2.0",
]


def _validate_runtime_dependencies():
    """
    Import the runtime dependencies and return (ok, message).

    This detects incomplete pydeps installations immediately rather than when
    the first NIfTI/MGH file is opened.
    """
    try:
        import packaging  # noqa: F401
        import nibabel  # noqa: F401
    except Exception as exc:
        return False, f"Runtime dependency import failed: {exc}"

    return True, "Runtime dependencies imported successfully."


def _have_module(mod_name: str) -> bool:
    try:
        import importlib.util as _util
        return _util.find_spec(mod_name) is not None
    except Exception:
        return False

def _missing_deps():
    missing = []
    for spec in _REQUIRED_PY_DEPS:
        # the top-level import name is the bit before any comparison operator
        top = spec.split("[")[0]
        for tok in ("==", ">=", "<=", "~=", ">", "<"):
            if tok in top:
                top = top.split(tok, 1)[0]
        top = top.strip()
        name = spec.split("[", 1)[0].split("==", 1)[0].split(">=", 1)[0].split("<=", 1)[0].split("~=", 1)[0].split(">", 1)[0].split("<", 1)[0].strip()
        if not _have_module(top or name):
            missing.append(spec)
    return missing

def _ensure_pip_available():
    try:
        import pip  # noqa: F401
        return True
    except Exception:
        try:
            import ensurepip
            ensurepip.bootstrap()  # installs pip into Blender's Python
            return True
        except Exception:
            return False

def _pip_install(packages, target_dir, verbose=False):
    os.makedirs(target_dir, exist_ok=True)

    # Upgrade pip silently (best effort)
    if _ensure_pip_available():
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        except Exception:
            pass
    else:
        raise RuntimeError("Could not bootstrap pip in Blender's Python (no ensurepip available).")

    base_cmd = [
        sys.executable, "-m", "pip", "install",
        "--target", target_dir,
        "--upgrade",
        "--prefer-binary",
        "--no-deps",
        "--no-warn-script-location",
    ]

    env = os.environ.copy()
    env.setdefault("PIP_DISABLE_PIP_VERSION_CHECK", "1")

    for pkg in packages:
        cmd = base_cmd + [pkg]
        proc = subprocess.run(
            cmd,
            check=False,
            stdout=(None if verbose else subprocess.PIPE),
            stderr=(None if verbose else subprocess.PIPE),
            env=env,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                f"pip failed for '{pkg}'. "
                f"Try again from Preferences or install manually."
            )

def _try_auto_install(verbose=False):
    missing = _missing_deps()
    if not missing:
        return True, "All dependencies present."

    try:
        _remove_local_numpy_shadow()

        _pip_install(missing, _DEP_DIR, verbose=verbose)

        _remove_local_numpy_shadow()

        if _DEP_DIR not in sys.path:
            sys.path.insert(0, _DEP_DIR)

        # Re-check
        still = _missing_deps()
        if still:
            return False, f"Installed some, but still missing: {', '.join(still)}"

        return True, "Dependencies installed."

    except Exception as e:
        return False, f"Auto-install failed: {e}"

# ---------------- Preferences UI (Install/Repair button) ----------------

class LTS_AddonPreferences(AddonPreferences):
    bl_idname = __name__

    auto_install: bpy.props.BoolProperty(
        name="Try auto-install on enable",
        default=True,
        description=(
            "When the add-on is enabled and a dependency is missing, "
            "attempt to install it into this add-on's 'pydeps' folder."
        ),
    )

    verbose_pip: bpy.props.BoolProperty(
        name="Verbose pip output (console)",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Python Dependencies", icon='SCRIPT')

        # status line
        missing = _missing_deps()

        row = box.row()
        row.label(
            text=f"OK: Blender NumPy {getattr(_blender_numpy, '__version__', 'unknown')} + numpy.ma",
            icon='CHECKMARK',
        )

        if _REMOVED_LOCAL_NUMPY:
            row = box.row()
            row.label(
                text="Removed a local pydeps NumPy shadow copy. Restart Blender once.",
                icon='INFO',
            )

        if not missing:
            row = box.row()
            row.label(
                text="OK: packaging and nibabel are available.",
                icon='CHECKMARK',
            )
        else:
            row = box.row()
            row.label(text=f"Missing: {', '.join(missing)}", icon='ERROR')

        col = box.column(align=True)
        col.prop(self, "auto_install")
        col.prop(self, "verbose_pip")
        col.separator()

        row = col.row(align=True)

        op = row.operator(
            "layer_tools.install_python_deps",
            text="Install/Repair Python Dependencies",
            icon='CONSOLE',
        )
        op.repair = False
        op.verbose = self.verbose_pip

        op2 = row.operator(
            "layer_tools.install_python_deps",
            text="Repair (clean & reinstall)",
            icon='FILE_REFRESH',
        )
        op2.repair = True
        op2.verbose = self.verbose_pip

        if os.path.isdir(_DEP_DIR):
            col.label(text=f"Local site-packages: {os.path.relpath(_DEP_DIR, _ADDON_DIR)}")

class LTS_OT_InstallDeps(Operator):
    bl_idname = "layer_tools.install_python_deps"
    bl_label = "Install or Repair Python Dependencies"
    bl_options = {'INTERNAL'}

    repair: bpy.props.BoolProperty(default=False)
    verbose: bpy.props.BoolProperty(default=False)

    def execute(self, context):
        try:
            if self.repair and os.path.isdir(_DEP_DIR):
                shutil.rmtree(_DEP_DIR, ignore_errors=True)

            # Ensure a NumPy shadow copy from an older add-on installation is
            # not retained or reintroduced.
            _remove_local_numpy_shadow()

            _pip_install(_REQUIRED_PY_DEPS, _DEP_DIR, verbose=self.verbose)

            _remove_local_numpy_shadow()

            if _DEP_DIR not in sys.path:
                sys.path.insert(0, _DEP_DIR)

            importlib.invalidate_caches()

            ok, message = _validate_runtime_dependencies()

            if not ok:
                raise RuntimeError(message)

        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        self.report(
            {'INFO'},
            "Dependencies installed: Blender NumPy + packaging + nibabel.",
        )
        return {'FINISHED'}

# ---------------- Module wiring ----------------

# Support both packaged and flat installs
if __package__ in (None, ""):
    _dir = os.path.dirname(__file__)
    if _dir and _dir not in sys.path:
        sys.path.append(_dir)

    common            = importlib.import_module("common")
    tab_nifti_paint   = importlib.import_module("tab_nifti_paint")
    tab_vertex_select = importlib.import_module("tab_vertex_select")
    tab_hipsta        = importlib.import_module("tab_hipsta")

else:
    from . import (
        common,
        tab_nifti_paint,
        tab_vertex_select,
        tab_hipsta,
    )

_submods = [
    common,
    tab_nifti_paint,
    tab_vertex_select,
    tab_hipsta,
]

# ---------------- Register / Unregister ----------------

_classes = (
    LTS_AddonPreferences,
    LTS_OT_InstallDeps,
)

def register():
    # Register prefs + operator first
    for c in _classes:
        bpy.utils.register_class(c)

    # Try auto install if requested and something is missing
    prefs = bpy.context.preferences.addons.get(__name__)
    auto = True
    verbose = False

    if prefs and hasattr(prefs, "preferences"):
        auto = prefs.preferences.auto_install
        verbose = prefs.preferences.verbose_pip

    if auto:
        ok, msg = _try_auto_install(verbose=verbose)

        if not ok:
            print(f"[Layer Tools Suite] {msg}")
        else:
            runtime_ok, runtime_msg = _validate_runtime_dependencies()

            if not runtime_ok:
                print(f"[Layer Tools Suite] {runtime_msg}")

    # Allow hot reloading from Blender’s Text Editor
    for m in _submods:
        importlib.reload(m)

    # Register submodules
    tab_nifti_paint.register()
    tab_vertex_select.register()
    tab_hipsta.register()

def unregister():
    # Unregister submodules in reverse order
    tab_hipsta.unregister()
    tab_vertex_select.unregister()
    tab_nifti_paint.unregister()

    for c in reversed(_classes):
        bpy.utils.unregister_class(c)