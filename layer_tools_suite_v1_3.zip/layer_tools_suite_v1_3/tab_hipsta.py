# tab_hipsta.py
#
# HipSTA surface visualisation and ROI tools for the Layer Tools Suite.
#
# Features
# --------
# - Loads HipSTA left/right mid, inner, and outer triangular VTK surfaces.
# - Loads per-vertex MGH overlays by vertex index:
#       thickness
#       hippocampal subfields
#       mean curvature
#       Gaussian curvature
# - Uses a shared display range when both hemispheres are loaded together.
# - Stores the current scalar values as a POINT-domain mesh attribute when the
#   Blender version supports generic mesh attributes.
# - Stores display colours as a vertex-colour attribute compatible with the
#   existing Layer Tools Suite material workflow.
# - Calculates statistics for selected vertices.
# - Selects vertices above/below a threshold, with explicit replace-selection
#   behaviour in both Object and Edit modes.
# - Creates a linked flat selection mesh from HipSTA's own intrinsic cube-grid
#   coordinates while preserving every original vertex index and face.
# - Transfers selections exactly between the flat and anatomical meshes.
# - Exports selected vertices and all available HipSTA measurements to CSV.
# - Exports selected vertices directly to a NIfTI ROI using the linked
#   anatomical HipSTA surface and hemisphere image as the FreeSurfer tkRAS
#   reference.
#
# Expected wrapper output layout
# ------------------------------
# <subject_dir>/
# ├── lh/
# │   ├── lh.image.mgz
# │   ├── lh.mask.mgz
# │   └── thickness/
# │       ├── lh.mid-surface.vtk
# │       ├── lh.mid-surface.csv
# │       ├── lh.mid-surface.thickness.mgh
# │       ├── lh.mid-surface.hsf.mgh
# │       ├── lh.mid-surface.mean-curv.mgh
# │       ├── lh.mid-surface.gauss-curv.mgh
# │       ├── lh.int-surface.vtk
# │       └── lh.ext-surface.vtk
# └── rh/
#     └── equivalent right-hemisphere outputs
#
# Coordinate convention
# ---------------------
# HipSTA surfaces are retained in their original local coordinates. HipSTA's
# surface creation uses FreeSurfer tkRAS coordinates relative to the processed
# hemisphere image/mask. For NIfTI export, this module uses:
#
#   voxel(target)
#       <- scanner RAS
#       <- voxel(HipSTA reference)
#       <- tkRAS(HipSTA surface)
#
# Do not apply object transforms to the anatomical HipSTA mesh before exporting
# a selected ROI. A flattened selection mesh may be translated for display, but
# ROI export always resolves back to the linked original anatomical surface.
#
# The flat view is intended for easier vertex selection. It uses HipSTA's
# intrinsic x/y grid coordinates:
#
#       x = medial -> lateral
#       y = posterior -> anterior
#
# The displayed grid is a parameter-space view, not a physical-mm surface. It
# must not be used for physical distance, area, curvature, or thickness
# calculations. HipSTA scalar measurements remain the original values.

from __future__ import annotations

import bmesh
import bpy
import csv
import os
import re

from pathlib import Path

import numpy as np

from .common import (
    abspath,
    auto_vmin_vmax,
    build_tkras_to_target_vox,
    get_nib,
    write_colours,
)


PANEL_CATEGORY = "HipSTA"
COLLECTION_NAME = "HipSTA"

COLOUR_ATTRIBUTE = "HipSTA_Col"
SCALAR_ATTRIBUTE = "HipSTA_Value"

SURFACE_ITEMS = [
    (
        "MID",
        "Mid surface",
        "Hippocampal mid-surface. Required for thickness and subfield overlays.",
    ),
    (
        "INT",
        "Inner surface",
        "Interior hippocampal surface.",
    ),
    (
        "EXT",
        "Outer surface",
        "Exterior hippocampal surface.",
    ),
]

HEMISPHERE_ITEMS = [
    ("LH", "Left", "Load the left hippocampus."),
    ("RH", "Right", "Load the right hippocampus."),
    ("BOTH", "Both", "Load both hippocampi with a shared colour range."),
]

OVERLAY_ITEMS = [
    (
        "THICKNESS",
        "Thickness",
        "Per-vertex hippocampal thickness. Available on the mid-surface.",
    ),
    (
        "HSF",
        "Hippocampal subfields",
        "Projected hippocampal subfield labels. Available on the mid-surface.",
    ),
    (
        "MEAN_CURV",
        "Mean curvature",
        "Per-vertex mean curvature for the selected surface.",
    ),
    (
        "GAUSS_CURV",
        "Gaussian curvature",
        "Per-vertex Gaussian curvature for the selected surface.",
    ),
    (
        "NONE",
        "No overlay",
        "Load the surface with a neutral grey material.",
    ),
]

PALETTE_ITEMS = [
    ("INFERNO", "Inferno", "Black-purple-orange-yellow sequential palette."),
    ("VIRIDIS", "Viridis", "Purple-blue-green-yellow sequential palette."),
    ("HOT", "Hot", "Black-red-yellow-white sequential palette."),
    ("JET", "Jet", "Blue-cyan-yellow-red palette."),
    ("BLUERED", "Blue–white–red", "Diverging blue-white-red palette."),
    ("GREYS", "Greys", "Black-to-white palette."),
]

THRESHOLD_ITEMS = [
    ("LESS", "Less than", "Select values below the threshold."),
    ("LESS_EQUAL", "Less than or equal", "Select values at or below the threshold."),
    ("GREATER", "Greater than", "Select values above the threshold."),
    ("GREATER_EQUAL", "Greater than or equal", "Select values at or above the threshold."),
]

LABEL_COLOURS = np.asarray(
    [
        (0.121, 0.466, 0.705),
        (1.000, 0.498, 0.054),
        (0.172, 0.627, 0.172),
        (0.839, 0.153, 0.157),
        (0.580, 0.404, 0.741),
        (0.549, 0.337, 0.294),
        (0.890, 0.467, 0.761),
        (0.498, 0.498, 0.498),
        (0.737, 0.741, 0.133),
        (0.090, 0.745, 0.811),
        (0.682, 0.780, 0.909),
        (1.000, 0.733, 0.470),
        (0.596, 0.875, 0.541),
        (1.000, 0.596, 0.588),
        (0.773, 0.690, 0.835),
        (0.769, 0.612, 0.580),
    ],
    dtype=np.float32,
)


# -------------------------------------------------------------------
# General helpers
# -------------------------------------------------------------------

def _safe_name(text, max_len=56):
    text = str(text or "").strip()

    for char in '<>:"/\\|?* \t\n\r':
        text = text.replace(char, "_")

    while "__" in text:
        text = text.replace("__", "_")

    text = text.strip("_") or "HipSTA"

    return text[:max_len]


def _surface_key(surface_type):
    surface_type = str(surface_type or "MID").upper()

    if surface_type not in {"MID", "INT", "EXT"}:
        raise RuntimeError(f"Unknown HipSTA surface type: {surface_type}")

    return surface_type.lower()


def _selected_hemispheres(value):
    value = str(value or "BOTH").upper()

    if value == "LH":
        return ["lh"]

    if value == "RH":
        return ["rh"]

    return ["lh", "rh"]


def _looks_like_subject_dir(path):
    path = Path(path)

    for hemi in ("lh", "rh"):
        if (
            (path / hemi / "thickness").is_dir()
            or (path / hemi / f"{hemi}.image.mgz").is_file()
            or (path / hemi / f"{hemi}.mask.mgz").is_file()
        ):
            return True

    return False


def resolve_subject_dir(raw_path):
    """
    Resolve a user-selected HipSTA path to the subject-level output directory.

    Accepted starting points include:
      <hipsta>/<subject>
      <hipsta>/<subject>/lh
      <hipsta>/<subject>/lh/thickness
      <hipsta>                         when exactly one subject is present
    """
    path_text = abspath(raw_path)

    if not path_text:
        raise RuntimeError("Set the HipSTA subject/output directory.")

    path = Path(path_text)

    if path.is_file():
        path = path.parent

    if not path.is_dir():
        raise RuntimeError(f"HipSTA path is not a directory: {path}")

    if path.name.lower() == "thickness" and path.parent.name.lower() in {"lh", "rh"}:
        path = path.parent.parent
    elif path.name.lower() in {"lh", "rh"}:
        path = path.parent

    if _looks_like_subject_dir(path):
        return path.resolve()

    candidates = sorted(
        [
            child.resolve()
            for child in path.iterdir()
            if child.is_dir() and _looks_like_subject_dir(child)
        ],
        key=lambda item: item.name.lower(),
    )

    if len(candidates) == 1:
        return candidates[0]

    if len(candidates) > 1:
        listing = "\n".join(f"  - {candidate}" for candidate in candidates)

        raise RuntimeError(
            "The selected directory contains more than one HipSTA subject. "
            "Select the subject-level directory directly:\n"
            f"{listing}"
        )

    raise RuntimeError(
        "Could not find a HipSTA subject layout beneath:\n"
        f"  {path}\n\n"
        "Expected lh/thickness and/or rh/thickness directories."
    )


def _hemi_dir(subject_dir, hemi):
    path = Path(subject_dir) / hemi

    if not path.is_dir():
        raise RuntimeError(
            f"HipSTA {hemi} directory was not found:\n  {path}"
        )

    return path


def _surface_path(subject_dir, hemi, surface_type):
    key = _surface_key(surface_type)
    path = _hemi_dir(subject_dir, hemi) / "thickness" / f"{hemi}.{key}-surface.vtk"

    if not path.is_file():
        raise RuntimeError(
            f"HipSTA {key}-surface was not found for {hemi}:\n  {path}"
        )

    return path.resolve()


def _surface_csv_path(subject_dir, hemi, surface_type):
    """
    Return the HipSTA surface CSV paired with the selected VTK surface.

    HipSTA writes the intrinsic cube-grid coordinates in columns 0:3 and the
    corresponding anatomical VTK coordinates in columns 3:6. The row order
    matches the VTK vertex order.
    """
    key = _surface_key(surface_type)
    path = (
        _hemi_dir(subject_dir, hemi)
        / "thickness"
        / f"{hemi}.{key}-surface.csv"
    )

    if not path.is_file():
        raise RuntimeError(
            "HipSTA intrinsic surface-coordinate CSV was not found:\n"
            f"  {path}\n\n"
            "This file is required for the intrinsic flat selection map."
        )

    return path.resolve()


def _overlay_path(subject_dir, hemi, surface_type, overlay_type):
    key = _surface_key(surface_type)
    overlay_type = str(overlay_type or "NONE").upper()
    thickness_dir = _hemi_dir(subject_dir, hemi) / "thickness"

    if overlay_type == "NONE":
        return None

    if overlay_type == "THICKNESS":
        if key != "mid":
            raise RuntimeError(
                "HipSTA thickness is defined on the mid-surface. "
                "Choose Mid surface or select another overlay."
            )

        path = thickness_dir / f"{hemi}.mid-surface.thickness.mgh"

    elif overlay_type == "HSF":
        if key != "mid":
            raise RuntimeError(
                "The HipSTA subfield overlay is defined on the mid-surface. "
                "Choose Mid surface or select another overlay."
            )

        path = thickness_dir / f"{hemi}.mid-surface.hsf.mgh"

    elif overlay_type == "MEAN_CURV":
        path = thickness_dir / f"{hemi}.{key}-surface.mean-curv.mgh"

    elif overlay_type == "GAUSS_CURV":
        path = thickness_dir / f"{hemi}.{key}-surface.gauss-curv.mgh"

    else:
        raise RuntimeError(f"Unknown HipSTA overlay type: {overlay_type}")

    if not path.is_file():
        raise RuntimeError(
            f"HipSTA overlay was not found:\n  {path}"
        )

    return path.resolve()


def _reference_mgz(subject_dir, hemi):
    hemi_dir = _hemi_dir(subject_dir, hemi)

    candidates = [
        hemi_dir / f"{hemi}.image.mgz",
        hemi_dir / f"{hemi}.mask.mgz",
        hemi_dir / f"{hemi}.labels.mgz",
    ]

    for path in candidates:
        if path.is_file():
            return path.resolve()

    listing = "\n".join(f"  - {path}" for path in candidates)

    raise RuntimeError(
        "No HipSTA reference MGZ was found. Checked:\n"
        f"{listing}"
    )


def _default_csv_path(obj):
    subject_dir = Path(str(obj.get("hipsta_subject_dir", "") or "."))

    return subject_dir / f"{_safe_name(obj.name)}_selected_vertices.csv"


def _default_roi_path(obj):
    subject_dir = Path(str(obj.get("hipsta_subject_dir", "") or "."))

    return subject_dir / f"{_safe_name(obj.name)}_selected_roi.nii.gz"


# -------------------------------------------------------------------
# HipSTA legacy VTK reader
# -------------------------------------------------------------------

def _find_token(tokens_upper, name, start=0):
    name = str(name).upper()

    for index in range(int(start), len(tokens_upper)):
        if tokens_upper[index] == name:
            return index

    return -1


def _fan_triangulate(indices):
    indices = [int(value) for value in indices]

    if len(indices) < 3:
        return []

    if len(indices) == 3:
        return [tuple(indices)]

    first = indices[0]

    return [
        (first, indices[index], indices[index + 1])
        for index in range(1, len(indices) - 1)
    ]


def _strip_triangulate(indices):
    indices = [int(value) for value in indices]
    triangles = []

    for index in range(len(indices) - 2):
        a, b, c = indices[index:index + 3]

        if index % 2:
            a, b = b, a

        if a != b and b != c and a != c:
            triangles.append((a, b, c))

    return triangles


def read_hipsta_vtk(path):
    """
    Read the legacy ASCII VTK POLYDATA written for HipSTA triangle surfaces.

    POINTS plus POLYGONS are expected. TRIANGLE_STRIPS and generic CELLS are
    also accepted as a defensive fallback. Polygons with more than three
    vertices are fan-triangulated.
    """
    path = Path(path)

    if not path.is_file():
        raise FileNotFoundError(path)

    raw = path.read_bytes()

    header = raw[:4096].decode("latin-1", errors="replace")
    header_lines = [line.strip() for line in header.splitlines()[:8]]

    if any(line.upper() == "BINARY" for line in header_lines):
        raise RuntimeError(
            "This HipSTA loader currently supports legacy ASCII VTK surfaces. "
            f"The selected file is binary:\n  {path}"
        )

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")

    tokens = text.replace("\r", " ").split()
    tokens_upper = [token.upper() for token in tokens]

    points_at = _find_token(tokens_upper, "POINTS")

    if points_at < 0 or points_at + 2 >= len(tokens):
        raise RuntimeError(
            f"VTK POINTS section was not found or was malformed:\n  {path}"
        )

    try:
        n_points = int(tokens[points_at + 1])
    except Exception as exc:
        raise RuntimeError(
            f"Could not read the VTK point count:\n  {path}"
        ) from exc

    start = points_at + 3
    stop = start + (3 * n_points)

    if stop > len(tokens):
        raise RuntimeError(
            f"VTK POINTS section is shorter than expected:\n  {path}"
        )

    try:
        points = np.asarray(
            [float(value) for value in tokens[start:stop]],
            dtype=np.float64,
        ).reshape(n_points, 3)
    except Exception as exc:
        raise RuntimeError(
            f"Could not parse VTK point coordinates:\n  {path}"
        ) from exc

    faces = []

    polygons_at = _find_token(tokens_upper, "POLYGONS", stop)

    if polygons_at >= 0:
        try:
            n_cells = int(tokens[polygons_at + 1])
        except Exception as exc:
            raise RuntimeError(
                f"Could not read VTK POLYGONS count:\n  {path}"
            ) from exc

        cursor = polygons_at + 3

        for _ in range(n_cells):
            if cursor >= len(tokens):
                raise RuntimeError(
                    f"VTK POLYGONS section ended unexpectedly:\n  {path}"
                )

            n_vertices = int(tokens[cursor])
            cursor += 1

            cell = [int(value) for value in tokens[cursor:cursor + n_vertices]]
            cursor += n_vertices
            faces.extend(_fan_triangulate(cell))

    else:
        strips_at = _find_token(tokens_upper, "TRIANGLE_STRIPS", stop)

        if strips_at >= 0:
            n_strips = int(tokens[strips_at + 1])
            cursor = strips_at + 3

            for _ in range(n_strips):
                n_vertices = int(tokens[cursor])
                cursor += 1

                strip = [
                    int(value)
                    for value in tokens[cursor:cursor + n_vertices]
                ]
                cursor += n_vertices
                faces.extend(_strip_triangulate(strip))

        else:
            cells_at = _find_token(tokens_upper, "CELLS", stop)

            if cells_at >= 0:
                n_cells = int(tokens[cells_at + 1])
                cursor = cells_at + 3

                for _ in range(n_cells):
                    n_vertices = int(tokens[cursor])
                    cursor += 1

                    cell = [
                        int(value)
                        for value in tokens[cursor:cursor + n_vertices]
                    ]
                    cursor += n_vertices
                    faces.extend(_fan_triangulate(cell))

    if not faces:
        raise RuntimeError(
            "No triangle faces were found in the HipSTA VTK surface:\n"
            f"  {path}"
        )

    faces = np.asarray(faces, dtype=np.int64)

    if np.min(faces) < 0 or np.max(faces) >= n_points:
        raise RuntimeError(
            "The HipSTA VTK contains a face index outside the valid vertex "
            f"range 0..{n_points - 1}:\n  {path}"
        )

    return points, faces


# -------------------------------------------------------------------
# Overlay reading and colour mapping
# -------------------------------------------------------------------

def load_overlay_values(path, n_vertices):
    nib = get_nib()
    image = nib.load(str(path))

    values = np.asarray(
        image.get_fdata(dtype=np.float32),
        dtype=np.float32,
    ).reshape(-1)

    if values.size != int(n_vertices):
        raise RuntimeError(
            "HipSTA overlay/mesh vertex mismatch:\n"
            f"  Overlay: {path}\n"
            f"  Overlay values: {values.size}\n"
            f"  Surface vertices: {n_vertices}\n\n"
            "The VTK surface and MGH overlay must come from the same HipSTA "
            "hemisphere and processing run."
        )

    return values


def _interp_palette(t, anchors):
    t = np.clip(np.asarray(t, dtype=np.float64), 0.0, 1.0)
    anchors = np.asarray(anchors, dtype=np.float64)

    x = np.linspace(0.0, 1.0, anchors.shape[0])

    rgb = np.column_stack(
        [
            np.interp(t, x, anchors[:, channel])
            for channel in range(3)
        ]
    )

    return np.clip(rgb, 0.0, 1.0).astype(np.float32)


def _palette_rgb(t, palette):
    palette = str(palette or "INFERNO").upper()
    t = np.clip(np.asarray(t, dtype=np.float64), 0.0, 1.0)

    if palette == "GREYS":
        return np.column_stack([t, t, t]).astype(np.float32)

    if palette == "BLUERED":
        signed = (2.0 * t) - 1.0
        rgb = np.zeros((t.size, 3), dtype=np.float32)

        negative = signed < 0
        positive = ~negative

        amount_negative = -signed[negative]
        amount_positive = signed[positive]

        rgb[negative, :] = np.column_stack(
            [
                1.0 - amount_negative,
                1.0 - amount_negative,
                np.ones_like(amount_negative),
            ]
        )

        rgb[positive, :] = np.column_stack(
            [
                np.ones_like(amount_positive),
                1.0 - amount_positive,
                1.0 - amount_positive,
            ]
        )

        return np.clip(rgb, 0.0, 1.0)

    if palette == "HOT":
        red = np.clip(3.0 * t, 0.0, 1.0)
        green = np.clip((3.0 * t) - 1.0, 0.0, 1.0)
        blue = np.clip((3.0 * t) - 2.0, 0.0, 1.0)

        return np.column_stack([red, green, blue]).astype(np.float32)

    if palette == "JET":
        red = np.clip(1.5 - np.abs((4.0 * t) - 3.0), 0.0, 1.0)
        green = np.clip(1.5 - np.abs((4.0 * t) - 2.0), 0.0, 1.0)
        blue = np.clip(1.5 - np.abs((4.0 * t) - 1.0), 0.0, 1.0)

        return np.column_stack([red, green, blue]).astype(np.float32)

    if palette == "VIRIDIS":
        return _interp_palette(
            t,
            [
                (0.267, 0.005, 0.329),
                (0.283, 0.141, 0.458),
                (0.254, 0.265, 0.530),
                (0.207, 0.372, 0.553),
                (0.164, 0.471, 0.558),
                (0.128, 0.567, 0.551),
                (0.135, 0.659, 0.518),
                (0.267, 0.749, 0.441),
                (0.478, 0.821, 0.318),
                (0.741, 0.873, 0.150),
                (0.993, 0.906, 0.144),
            ],
        )

    # INFERNO
    return _interp_palette(
        t,
        [
            (0.001, 0.000, 0.014),
            (0.073, 0.016, 0.178),
            (0.221, 0.037, 0.388),
            (0.365, 0.071, 0.432),
            (0.522, 0.128, 0.420),
            (0.675, 0.214, 0.368),
            (0.816, 0.320, 0.264),
            (0.925, 0.468, 0.165),
            (0.988, 0.645, 0.039),
            (0.988, 0.835, 0.266),
            (0.988, 0.998, 0.645),
        ],
    )


def continuous_rgba(values, vmin, vmax, palette, invert=False):
    values = np.asarray(values, dtype=np.float64)

    if vmax <= vmin:
        vmax = vmin + 1e-6

    t = (values - float(vmin)) / float(vmax - vmin)

    if invert:
        t = 1.0 - t

    rgb = _palette_rgb(t, palette)

    invalid = ~np.isfinite(values)

    if np.any(invalid):
        rgb[invalid, :] = (0.25, 0.25, 0.25)

    alpha = np.ones((values.size, 1), dtype=np.float32)

    return np.concatenate([rgb, alpha], axis=1)


def categorical_rgba(values):
    values = np.asarray(values, dtype=np.float64)
    rounded = np.rint(values).astype(np.int64)

    finite = np.isfinite(values)

    labels = sorted(
        int(label)
        for label in np.unique(rounded[finite])
        if int(label) != 0
    )

    rgba = np.zeros((values.size, 4), dtype=np.float32)
    rgba[:, :] = (0.20, 0.20, 0.20, 1.0)

    mapping = {}

    for index, label in enumerate(labels):
        colour = LABEL_COLOURS[index % len(LABEL_COLOURS)]
        mapping[label] = tuple(float(value) for value in colour)

        mask = finite & (rounded == label)
        rgba[mask, 0:3] = colour

    rgba[~finite, :] = (0.10, 0.10, 0.10, 1.0)

    return rgba, labels, mapping


def _range_from_values(values, props):
    finite = np.asarray(values, dtype=np.float64)
    finite = finite[np.isfinite(finite)]

    if finite.size == 0:
        return 0.0, 1.0

    if props.use_auto_range:
        vmin, vmax = auto_vmin_vmax(
            finite,
            symmetric=bool(props.symmetric),
            p_lo=float(props.p_lo),
            p_hi=float(props.p_hi),
        )
    else:
        vmin = float(props.vmin)
        vmax = float(props.vmax)

        if props.symmetric:
            amount = max(abs(vmin), abs(vmax))
            vmin, vmax = -amount, amount

    if vmax <= vmin:
        vmax = vmin + 1e-6

    return float(vmin), float(vmax)


# -------------------------------------------------------------------
# Blender mesh attributes and material
# -------------------------------------------------------------------

def write_float_point_attribute(mesh, values, name=SCALAR_ATTRIBUTE):
    """
    Store real scalar values as a POINT-domain FLOAT attribute when supported.

    Blender 2.93 does not expose the same generic attribute API. In that case,
    the MGH path is retained on the object and values are reloaded by index for
    statistics and export.
    """
    attributes = getattr(mesh, "attributes", None)

    if attributes is None:
        return False

    attribute = attributes.get(name)

    if attribute is not None:
        if attribute.domain != "POINT" or attribute.data_type != "FLOAT":
            attributes.remove(attribute)
            attribute = None

    if attribute is None:
        attribute = attributes.new(
            name=name,
            type="FLOAT",
            domain="POINT",
        )

    values = np.asarray(values, dtype=np.float32).reshape(-1)

    if len(attribute.data) != values.size:
        raise RuntimeError(
            f"Cannot write scalar attribute '{name}': "
            f"{len(attribute.data)} mesh points versus {values.size} values."
        )

    try:
        attribute.data.foreach_set("value", values)
    except Exception:
        for index, value in enumerate(values):
            attribute.data[index].value = float(value)

    return True


def ensure_hipsta_material(obj, colour_attribute=COLOUR_ATTRIBUTE):
    material_name = f"{_safe_name(obj.name)}_Material"

    material = bpy.data.materials.get(material_name)

    if material is None:
        material = bpy.data.materials.new(name=material_name)

    material.use_nodes = True
    material["hipsta_material"] = True
    material["hipsta_colour_attribute"] = str(colour_attribute)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (420, 0)

    shader = nodes.new("ShaderNodeBsdfPrincipled")
    shader.location = (160, 0)

    colour = nodes.new("ShaderNodeAttribute")
    colour.attribute_name = str(colour_attribute)
    colour.location = (-180, 0)

    links.new(colour.outputs["Color"], shader.inputs["Base Color"])
    links.new(shader.outputs["BSDF"], output.inputs["Surface"])

    if "Roughness" in shader.inputs:
        shader.inputs["Roughness"].default_value = 0.65

    if obj.data.materials:
        obj.data.materials[0] = material
    else:
        obj.data.materials.append(material)

    for polygon in obj.data.polygons:
        polygon.material_index = 0

    obj.active_material_index = 0
    obj.data.update()

    return material


def _set_neutral_surface(obj):
    rgba = np.tile(
        np.asarray([[0.62, 0.62, 0.65, 1.0]], dtype=np.float32),
        (len(obj.data.vertices), 1),
    )

    write_colours(obj.data, rgba, COLOUR_ATTRIBUTE)
    ensure_hipsta_material(obj, COLOUR_ATTRIBUTE)


def apply_overlay_to_object(
    obj,
    values,
    overlay_type,
    overlay_path,
    props,
    vmin=None,
    vmax=None,
):
    overlay_type = str(overlay_type or "NONE").upper()

    if overlay_type == "NONE" or values is None:
        _set_neutral_surface(obj)

        obj["hipsta_overlay_type"] = "NONE"
        obj["hipsta_overlay_path"] = ""
        obj["hipsta_display_min"] = 0.0
        obj["hipsta_display_max"] = 1.0
        obj["hipsta_label_values"] = ""

        return 0.0, 1.0

    values = np.asarray(values, dtype=np.float32).reshape(-1)

    if values.size != len(obj.data.vertices):
        raise RuntimeError(
            f"Overlay contains {values.size} values but '{obj.name}' has "
            f"{len(obj.data.vertices)} vertices."
        )

    if overlay_type == "HSF":
        rgba, labels, _ = categorical_rgba(values)

        used_vmin = float(np.nanmin(values)) if np.isfinite(values).any() else 0.0
        used_vmax = float(np.nanmax(values)) if np.isfinite(values).any() else 1.0

        obj["hipsta_label_values"] = ",".join(str(value) for value in labels)

    else:
        if vmin is None or vmax is None:
            used_vmin, used_vmax = _range_from_values(values, props)
        else:
            used_vmin = float(vmin)
            used_vmax = float(vmax)

        rgba = continuous_rgba(
            values,
            used_vmin,
            used_vmax,
            palette=props.palette,
            invert=props.invert_palette,
        )

        obj["hipsta_label_values"] = ""

    write_colours(obj.data, rgba, COLOUR_ATTRIBUTE)
    wrote_scalar = write_float_point_attribute(
        obj.data,
        values,
        SCALAR_ATTRIBUTE,
    )

    ensure_hipsta_material(obj, COLOUR_ATTRIBUTE)

    obj["hipsta_overlay_type"] = overlay_type
    obj["hipsta_overlay_path"] = str(overlay_path or "")
    obj["hipsta_scalar_attribute"] = SCALAR_ATTRIBUTE if wrote_scalar else ""
    obj["hipsta_colour_attribute"] = COLOUR_ATTRIBUTE
    obj["hipsta_display_min"] = float(used_vmin)
    obj["hipsta_display_max"] = float(used_vmax)
    obj["hipsta_palette"] = str(props.palette)
    obj["hipsta_palette_inverted"] = bool(props.invert_palette)

    return float(used_vmin), float(used_vmax)


# -------------------------------------------------------------------
# Blender object creation
# -------------------------------------------------------------------

def _hipsta_collection():
    collection = bpy.data.collections.get(COLLECTION_NAME)

    if collection is None:
        collection = bpy.data.collections.new(COLLECTION_NAME)
        bpy.context.scene.collection.children.link(collection)

    return collection


def _remove_object_and_mesh(obj):
    mesh = obj.data if obj and obj.type == "MESH" else None

    bpy.data.objects.remove(obj, do_unlink=True)

    if mesh is not None and mesh.users == 0:
        bpy.data.meshes.remove(mesh)


def _create_surface_object(
    context,
    subject_dir,
    hemi,
    surface_type,
    surface_path,
    points,
    faces,
    reference_path,
    props,
):
    key = _surface_key(surface_type)
    object_name = f"HipSTA_{hemi}_{key}"

    existing = bpy.data.objects.get(object_name)

    if existing is not None and props.replace_existing:
        _remove_object_and_mesh(existing)
        existing = None

    if existing is not None:
        base_name = object_name
        counter = 2

        while bpy.data.objects.get(f"{base_name}_{counter:02d}") is not None:
            counter += 1

        object_name = f"{base_name}_{counter:02d}"

    mesh = bpy.data.meshes.new(f"{object_name}_Mesh")
    mesh.from_pydata(
        points.astype(np.float64).tolist(),
        [],
        faces.astype(np.int64).tolist(),
    )
    mesh.validate(clean_customdata=False)
    mesh.update(calc_edges=True)

    obj = bpy.data.objects.new(object_name, mesh)
    _hipsta_collection().objects.link(obj)

    for polygon in mesh.polygons:
        polygon.use_smooth = bool(props.smooth_shading)

    obj["hipsta_surface"] = True
    obj["hipsta_subject_dir"] = str(Path(subject_dir).resolve())
    obj["hipsta_hemi"] = str(hemi)
    obj["hipsta_surface_type"] = str(key)
    obj["hipsta_surface_path"] = str(Path(surface_path).resolve())
    obj["hipsta_reference_mgz"] = str(Path(reference_path).resolve())
    obj["hipsta_coordinate_space"] = "FS_TKRAS"
    obj["hipsta_vertex_count"] = int(len(mesh.vertices))
    obj["hipsta_face_count"] = int(len(mesh.polygons))

    # Also expose metadata names used elsewhere in the Layer Tools Suite.
    obj["nifti_surface_space"] = "FS_TKRAS"
    obj["fs_ref_path"] = str(Path(reference_path).resolve())

    return obj


def _activate_objects(context, objects):
    for selected in list(context.selected_objects):
        selected.select_set(False)

    for obj in objects:
        obj.select_set(True)

    if objects:
        context.view_layer.objects.active = objects[-1]


def _active_hipsta_object(context):
    obj = context.active_object

    if not obj or obj.type != "MESH":
        raise RuntimeError("Select a HipSTA mesh object.")

    if not bool(obj.get("hipsta_surface", False)):
        raise RuntimeError(
            f"The active mesh '{obj.name}' is not marked as a HipSTA surface."
        )

    return obj


# -------------------------------------------------------------------
# Linked anatomical / flat-selection helpers
# -------------------------------------------------------------------

def _anatomical_source_object(obj):
    """
    Return the original anatomical HipSTA object for obj.

    Anatomical HipSTA objects return themselves. Flat selection objects resolve
    the object name stored in hipsta_source_object and require identical vertex
    counts so vertex-index mapping remains exact.
    """
    if not bool(obj.get("hipsta_flattened", False)):
        return obj

    source_name = str(obj.get("hipsta_source_object", "") or "")
    source = bpy.data.objects.get(source_name)

    if source is None or source.type != "MESH":
        raise RuntimeError(
            f"The flat HipSTA mesh '{obj.name}' is linked to a missing "
            f"anatomical object: {source_name or '<not set>'}"
        )

    if not bool(source.get("hipsta_surface", False)):
        raise RuntimeError(
            f"The linked object '{source.name}' is not marked as a HipSTA surface."
        )

    if bool(source.get("hipsta_flattened", False)):
        raise RuntimeError(
            f"The linked source '{source.name}' is itself a flat selection mesh."
        )

    if len(source.data.vertices) != len(obj.data.vertices):
        raise RuntimeError(
            "Flat/anatomical HipSTA vertex-count mismatch:\n"
            f"  Flat: {obj.name} ({len(obj.data.vertices)})\n"
            f"  Anatomical: {source.name} ({len(source.data.vertices)})"
        )

    return source


def _selection_mask(obj):
    mask = np.zeros(len(obj.data.vertices), dtype=bool)

    indices = selected_vertex_indices(obj)

    if indices:
        mask[np.asarray(indices, dtype=np.int64)] = True

    return mask


def load_intrinsic_surface_coordinates(
    csv_path,
    n_vertices,
    anatomical_points=None,
    coordinate_tolerance=1e-3,
):
    """
    Load and validate HipSTA's per-vertex intrinsic surface-coordinate CSV.

    HipSTA writes each surface CSV as six columns:

        0  intrinsic x-grid index  (medial -> lateral)
        1  intrinsic y-grid index  (posterior -> anterior)
        2  intrinsic z-grid index  (exterior -> interior)
        3  anatomical VTK x
        4  anatomical VTK y
        5  anatomical VTK z

    The CSV and corresponding VTK are produced from the same ordered vertex
    arrays. We verify the row count and, when anatomical_points is supplied,
    verify the final three columns against the loaded VTK coordinates.
    """
    csv_path = Path(csv_path)

    if not csv_path.is_file():
        raise RuntimeError(
            f"HipSTA intrinsic surface CSV was not found:\n  {csv_path}"
        )

    try:
        data = np.loadtxt(
            str(csv_path),
            delimiter=",",
            dtype=np.float64,
            ndmin=2,
        )
    except Exception as exc:
        raise RuntimeError(
            f"Could not read HipSTA surface CSV:\n  {csv_path}\n\n{exc}"
        ) from exc

    if data.ndim != 2 or data.shape[1] < 6:
        raise RuntimeError(
            "HipSTA surface CSV must contain at least six numeric columns:\n"
            "  intrinsic x, y, z, anatomical x, y, z\n\n"
            f"Found shape {data.shape} in:\n  {csv_path}"
        )

    if data.shape[0] != int(n_vertices):
        raise RuntimeError(
            "HipSTA surface CSV/VTK vertex mismatch:\n"
            f"  CSV rows: {data.shape[0]}\n"
            f"  Surface vertices: {n_vertices}\n"
            f"  CSV: {csv_path}"
        )

    intrinsic = np.asarray(data[:, 0:3], dtype=np.float64)
    csv_anatomical = np.asarray(data[:, 3:6], dtype=np.float64)

    if not np.all(np.isfinite(intrinsic)):
        raise RuntimeError(
            f"HipSTA intrinsic coordinates contain non-finite values:\n  {csv_path}"
        )

    if not np.all(np.isfinite(csv_anatomical)):
        raise RuntimeError(
            f"HipSTA anatomical CSV coordinates contain non-finite values:\n  {csv_path}"
        )

    if anatomical_points is not None:
        anatomical_points = np.asarray(
            anatomical_points,
            dtype=np.float64,
        )

        if anatomical_points.shape != csv_anatomical.shape:
            raise RuntimeError(
                "HipSTA VTK/CSV anatomical coordinate shape mismatch:\n"
                f"  VTK: {anatomical_points.shape}\n"
                f"  CSV: {csv_anatomical.shape}"
            )

        absolute_error = np.abs(
            anatomical_points - csv_anatomical
        )

        max_error = float(np.max(absolute_error))
        rms_error = float(
            np.sqrt(np.mean(np.square(absolute_error)))
        )

        if not np.allclose(
            anatomical_points,
            csv_anatomical,
            rtol=1e-5,
            atol=float(coordinate_tolerance),
        ):
            raise RuntimeError(
                "The HipSTA surface CSV does not match the loaded VTK vertex "
                "coordinates/order.\n\n"
                f"Maximum coordinate difference: {max_error:.6g}\n"
                f"RMS coordinate difference: {rms_error:.6g}\n"
                f"Tolerance: {coordinate_tolerance:.6g}\n"
                f"CSV: {csv_path}\n\n"
                "Use the CSV and VTK from the same hemisphere, surface, and "
                "HipSTA processing run."
            )
    else:
        max_error = float("nan")
        rms_error = float("nan")

    xy = intrinsic[:, 0:2]
    unique_xy = np.unique(
        np.round(xy, decimals=8),
        axis=0,
    )

    if unique_xy.shape[0] != xy.shape[0]:
        raise RuntimeError(
            "HipSTA intrinsic x/y coordinates are not unique on this surface. "
            "A one-to-one flat selection map cannot be created safely.\n"
            f"CSV: {csv_path}"
        )

    z_values = np.unique(
        np.round(intrinsic[:, 2], decimals=8)
    )

    return intrinsic, {
        "csv_path": str(csv_path.resolve()),
        "x_min": float(np.min(intrinsic[:, 0])),
        "x_max": float(np.max(intrinsic[:, 0])),
        "y_min": float(np.min(intrinsic[:, 1])),
        "y_max": float(np.max(intrinsic[:, 1])),
        "z_values": [float(value) for value in z_values],
        "max_coordinate_error": max_error,
        "rms_coordinate_error": rms_error,
    }


def flatten_surface_from_intrinsic_grid(
    points,
    faces,
    intrinsic_coordinates,
    x_scale=1.0,
    y_scale=1.0,
    flip_x=False,
    flip_y=False,
):
    """
    Create a planar selection mesh from HipSTA intrinsic grid coordinates.

    Flat X:
        HipSTA x coordinate, medial -> lateral.

    Flat Y:
        HipSTA y coordinate, posterior -> anterior.

    Flat Z:
        zero.

    Every source vertex and every source face is retained. No seam is cut and
    no projection is performed. Therefore, vertex-index correspondence with the
    anatomical HipSTA surface remains exact.
    """
    points = np.asarray(points, dtype=np.float64)
    faces_array = np.asarray(faces, dtype=np.int64)
    intrinsic = np.asarray(
        intrinsic_coordinates,
        dtype=np.float64,
    )

    if points.ndim != 2 or points.shape[1] != 3:
        raise RuntimeError("HipSTA anatomical points must be an Nx3 array.")

    if intrinsic.shape != points.shape:
        raise RuntimeError(
            "HipSTA intrinsic/anatomical coordinate shape mismatch:\n"
            f"  Intrinsic: {intrinsic.shape}\n"
            f"  Anatomical: {points.shape}"
        )

    if faces_array.ndim != 2 or faces_array.shape[1] != 3:
        raise RuntimeError("HipSTA flat mapping requires triangular faces.")

    if faces_array.size:
        if np.min(faces_array) < 0 or np.max(faces_array) >= len(points):
            raise RuntimeError(
                "HipSTA face indices fall outside the valid vertex range."
            )

    x_scale = max(1e-6, float(x_scale))
    y_scale = max(1e-6, float(y_scale))

    x_raw = intrinsic[:, 0].copy()
    y_raw = intrinsic[:, 1].copy()

    x_min = float(np.min(x_raw))
    x_max = float(np.max(x_raw))
    y_min = float(np.min(y_raw))
    y_max = float(np.max(y_raw))

    x = x_raw - x_min
    y = y_raw - y_min

    if bool(flip_x):
        x = (x_max - x_min) - x

    if bool(flip_y):
        y = (y_max - y_min) - y

    flat_points = np.column_stack(
        [
            x * x_scale,
            y * y_scale,
            np.zeros(points.shape[0], dtype=np.float64),
        ]
    )

    # Keep every original face. Unlike the previous cylindrical method, this
    # intrinsic parameter map requires no seam and therefore creates no tears.
    flat_faces = [
        tuple(int(value) for value in face)
        for face in faces_array
    ]

    if not flat_faces:
        raise RuntimeError("The HipSTA source surface contains no faces.")

    # Detect degenerate triangles in parameter space. These should not occur
    # for a correctly paired HipSTA surface CSV and VTK.
    tri = flat_points[faces_array, 0:2]

    twice_area = (
        (tri[:, 1, 0] - tri[:, 0, 0])
        * (tri[:, 2, 1] - tri[:, 0, 1])
        - (tri[:, 1, 1] - tri[:, 0, 1])
        * (tri[:, 2, 0] - tri[:, 0, 0])
    )

    degenerate = np.abs(twice_area) <= 1e-12

    if np.any(degenerate):
        raise RuntimeError(
            "The HipSTA intrinsic flat map contains "
            f"{int(np.count_nonzero(degenerate))} degenerate triangle(s). "
            "The surface CSV may not correspond to this VTK surface."
        )

    return flat_points, flat_faces, {
        "method": "HIPSTA_INTRINSIC_GRID",
        "x_min": x_min,
        "x_max": x_max,
        "y_min": y_min,
        "y_max": y_max,
        "x_scale": x_scale,
        "y_scale": y_scale,
        "flip_x": bool(flip_x),
        "flip_y": bool(flip_y),
        "vertex_count": int(len(points)),
        "face_count": int(len(flat_faces)),
    }


def _copy_hipsta_metadata(source, target):
    """Copy known HipSTA metadata required by overlays, CSV, and ROI export."""
    keys = [
        "hipsta_subject_dir",
        "hipsta_hemi",
        "hipsta_surface_type",
        "hipsta_surface_path",
        "hipsta_reference_mgz",
        "hipsta_coordinate_space",
        "hipsta_overlay_type",
        "hipsta_overlay_path",
        "hipsta_scalar_attribute",
        "hipsta_colour_attribute",
        "hipsta_display_min",
        "hipsta_display_max",
        "hipsta_palette",
        "hipsta_palette_inverted",
        "hipsta_label_values",
        "fs_ref_path",
    ]

    for key in keys:
        if key in source:
            target[key] = source[key]


def _unique_flat_object_name(source):
    base_name = f"{source.name}_intrinsic_flat"

    if bpy.data.objects.get(base_name) is None:
        return base_name

    counter = 2

    while bpy.data.objects.get(f"{base_name}_{counter:02d}") is not None:
        counter += 1

    return f"{base_name}_{counter:02d}"


def create_flat_selection_object(context, source, props):
    """
    Create a linked intrinsic-grid HipSTA selection mesh.

    The flat object:
      - retains every source vertex and face;
      - preserves exact vertex indices;
      - uses HipSTA x/y cube-grid coordinates for display;
      - links back to source for anatomical coordinates, normals, NIfTI export,
        and physical measurements.
    """
    source = _anatomical_source_object(source)

    points = np.asarray(
        [tuple(vertex.co) for vertex in source.data.vertices],
        dtype=np.float64,
    )

    faces = np.asarray(
        [tuple(polygon.vertices) for polygon in source.data.polygons],
        dtype=np.int64,
    )

    subject_dir = Path(str(source.get("hipsta_subject_dir", "")))
    hemi = str(source.get("hipsta_hemi", ""))
    surface_type = str(source.get("hipsta_surface_type", "")).upper()

    intrinsic_csv = _surface_csv_path(
        subject_dir,
        hemi,
        surface_type,
    )

    intrinsic, csv_info = load_intrinsic_surface_coordinates(
        intrinsic_csv,
        n_vertices=len(points),
        anatomical_points=points,
        coordinate_tolerance=float(
            props.intrinsic_coordinate_tolerance
        ),
    )

    flat_points, flat_faces, info = (
        flatten_surface_from_intrinsic_grid(
            points=points,
            faces=faces,
            intrinsic_coordinates=intrinsic,
            x_scale=props.intrinsic_x_scale,
            y_scale=props.intrinsic_y_scale,
            flip_x=props.intrinsic_flip_x,
            flip_y=props.intrinsic_flip_y,
        )
    )

    expected_name = f"{source.name}_intrinsic_flat"

    if props.replace_flattened:
        linked_flats = [
            obj
            for obj in list(bpy.data.objects)
            if obj.type == "MESH"
            and bool(obj.get("hipsta_flattened", False))
            and str(obj.get("hipsta_source_object", "")) == source.name
        ]

        for existing in linked_flats:
            _remove_object_and_mesh(existing)

    existing = bpy.data.objects.get(expected_name)

    object_name = (
        expected_name
        if existing is None
        else _unique_flat_object_name(source)
    )

    mesh = bpy.data.meshes.new(f"{object_name}_Mesh")
    mesh.from_pydata(
        flat_points.tolist(),
        [],
        flat_faces,
    )
    mesh.validate(clean_customdata=False)
    mesh.update(calc_edges=True)

    flat = bpy.data.objects.new(object_name, mesh)
    _hipsta_collection().objects.link(flat)

    for polygon in mesh.polygons:
        polygon.use_smooth = bool(props.smooth_shading)

    _copy_hipsta_metadata(source, flat)

    flat["hipsta_surface"] = True
    flat["hipsta_flattened"] = True
    flat["hipsta_source_object"] = source.name
    flat["hipsta_flatten_method"] = "HIPSTA_INTRINSIC_GRID"
    flat["hipsta_intrinsic_csv"] = str(intrinsic_csv)
    flat["hipsta_intrinsic_x_min"] = float(info["x_min"])
    flat["hipsta_intrinsic_x_max"] = float(info["x_max"])
    flat["hipsta_intrinsic_y_min"] = float(info["y_min"])
    flat["hipsta_intrinsic_y_max"] = float(info["y_max"])
    flat["hipsta_intrinsic_x_scale"] = float(info["x_scale"])
    flat["hipsta_intrinsic_y_scale"] = float(info["y_scale"])
    flat["hipsta_intrinsic_flip_x"] = bool(info["flip_x"])
    flat["hipsta_intrinsic_flip_y"] = bool(info["flip_y"])
    flat["hipsta_intrinsic_z_values"] = ",".join(
        f"{value:.8g}" for value in csv_info["z_values"]
    )
    flat["hipsta_intrinsic_csv_max_error"] = float(
        csv_info["max_coordinate_error"]
    )
    flat["hipsta_intrinsic_csv_rms_error"] = float(
        csv_info["rms_coordinate_error"]
    )
    flat["hipsta_flatten_omitted_seam_faces"] = 0
    flat["hipsta_vertex_count"] = int(len(mesh.vertices))
    flat["hipsta_face_count"] = int(len(mesh.polygons))

    # Prevent generic surface tools from interpreting parameter-grid display
    # coordinates as anatomical tkRAS coordinates.
    flat["nifti_surface_space"] = "HIPSTA_INTRINSIC_FLAT_SELECTION"

    flat.location = source.location.copy()
    flat.location.x += float(props.flatten_offset_x)

    overlay_type = str(
        source.get("hipsta_overlay_type", "NONE")
    ).upper()

    overlay_path_text = str(
        source.get("hipsta_overlay_path", "") or ""
    )

    values = None
    overlay_path = None

    if (
        overlay_type != "NONE"
        and overlay_path_text
        and os.path.isfile(overlay_path_text)
    ):
        overlay_path = Path(overlay_path_text)

        values = load_overlay_values(
            overlay_path,
            len(mesh.vertices),
        )

    source_vmin = float(
        source.get("hipsta_display_min", 0.0)
    )
    source_vmax = float(
        source.get("hipsta_display_max", 1.0)
    )

    apply_overlay_to_object(
        obj=flat,
        values=values,
        overlay_type=overlay_type,
        overlay_path=overlay_path,
        props=props,
        vmin=(
            source_vmin
            if overlay_type not in {"NONE", "HSF"}
            else None
        ),
        vmax=(
            source_vmax
            if overlay_type not in {"NONE", "HSF"}
            else None
        ),
    )

    # Preserve the source selection by exact vertex index.
    source_selection = _selection_mask(source)

    _set_selection(
        flat,
        source_selection,
        clear_existing=True,
    )

    combined_info = dict(info)
    combined_info.update(csv_info)

    return flat, combined_info


def _transfer_selection(source_obj, target_obj, clear_existing=True):
    """Transfer vertex selection by exact index between linked HipSTA meshes."""
    if len(source_obj.data.vertices) != len(target_obj.data.vertices):
        raise RuntimeError(
            "Cannot transfer selection because vertex counts differ:\n"
            f"  {source_obj.name}: {len(source_obj.data.vertices)}\n"
            f"  {target_obj.name}: {len(target_obj.data.vertices)}"
        )

    mask = _selection_mask(source_obj)

    _set_selection(
        target_obj,
        mask,
        clear_existing=clear_existing,
    )

    return int(np.count_nonzero(mask))


# -------------------------------------------------------------------
# Current object values and selections
# -------------------------------------------------------------------

def _current_overlay_values(obj):
    overlay_type = str(obj.get("hipsta_overlay_type", "NONE")).upper()
    overlay_path = str(obj.get("hipsta_overlay_path", "") or "")

    if overlay_type == "NONE" or not overlay_path:
        raise RuntimeError(
            f"'{obj.name}' does not currently have a HipSTA scalar overlay."
        )

    if not os.path.isfile(overlay_path):
        raise RuntimeError(
            f"The current HipSTA overlay file no longer exists:\n  {overlay_path}"
        )

    return (
        overlay_type,
        Path(overlay_path),
        load_overlay_values(overlay_path, len(obj.data.vertices)),
    )


def selected_vertex_indices(obj):
    if bpy.context.object == obj and bpy.context.mode == "EDIT_MESH":
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()

        return [vertex.index for vertex in bm.verts if vertex.select]

    return [vertex.index for vertex in obj.data.vertices if vertex.select]


def _mesh_local_vertices_and_normals(obj):
    mesh = obj.data

    if hasattr(mesh, "calc_normals"):
        mesh.calc_normals()
    elif hasattr(mesh, "calc_normals_split"):
        mesh.calc_normals_split()

    vertices = np.asarray(
        [tuple(vertex.co) for vertex in mesh.vertices],
        dtype=np.float64,
    )

    normals = np.asarray(
        [tuple(vertex.normal) for vertex in mesh.vertices],
        dtype=np.float64,
    )

    lengths = np.linalg.norm(normals, axis=1, keepdims=True)
    normals = normals / np.maximum(lengths, 1e-12)

    return vertices, normals


def _set_selection(obj, mask, clear_existing=True):
    """
    Apply a vertex-selection mask reliably in both Edit and Object modes.

    When clear_existing=True, every existing selection is explicitly cleared
    before the new mask is applied. This is the behaviour required by
    "Replace current selection".
    """
    mask = np.asarray(mask, dtype=bool)

    if mask.size != len(obj.data.vertices):
        raise RuntimeError("Selection mask and mesh vertex count do not match.")

    selected_indices = np.flatnonzero(mask)

    is_active_edit_mesh = (
        bpy.context.object == obj
        and bpy.context.mode == "EDIT_MESH"
    )

    if is_active_edit_mesh:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()

        if clear_existing:
            for vertex in bm.verts:
                vertex.select_set(False)

        for index in selected_indices:
            bm.verts[int(index)].select_set(True)

        try:
            bm.select_flush_mode()
        except Exception:
            pass

        bmesh.update_edit_mesh(
            obj.data,
            loop_triangles=False,
            destructive=False,
        )

        return

    if clear_existing:
        for vertex in obj.data.vertices:
            vertex.select = False

    for index in selected_indices:
        obj.data.vertices[int(index)].select = True

    obj.data.update()


# -------------------------------------------------------------------
# CSV measurement collection
# -------------------------------------------------------------------

def _try_load_measurement(path, n_vertices):
    path = Path(path)

    if not path.is_file():
        return None

    try:
        values = load_overlay_values(path, n_vertices)
    except Exception:
        return None

    return values


def available_measurements_for_object(obj):
    subject_dir = Path(str(obj.get("hipsta_subject_dir", "")))
    hemi = str(obj.get("hipsta_hemi", "lh"))
    surface = str(obj.get("hipsta_surface_type", "mid"))
    thickness_dir = subject_dir / hemi / "thickness"
    n_vertices = len(obj.data.vertices)

    measurements = {}

    mean_path = thickness_dir / f"{hemi}.{surface}-surface.mean-curv.mgh"
    gauss_path = thickness_dir / f"{hemi}.{surface}-surface.gauss-curv.mgh"

    measurements["mean_curvature"] = _try_load_measurement(
        mean_path,
        n_vertices,
    )
    measurements["gaussian_curvature"] = _try_load_measurement(
        gauss_path,
        n_vertices,
    )

    if surface == "mid":
        thickness_path = thickness_dir / f"{hemi}.mid-surface.thickness.mgh"
        hsf_path = thickness_dir / f"{hemi}.mid-surface.hsf.mgh"

        measurements["thickness_mm"] = _try_load_measurement(
            thickness_path,
            n_vertices,
        )
        measurements["subfield_label"] = _try_load_measurement(
            hsf_path,
            n_vertices,
        )
    else:
        measurements["thickness_mm"] = None
        measurements["subfield_label"] = None

    return measurements


# -------------------------------------------------------------------
# NIfTI ROI export
# -------------------------------------------------------------------

def _stamp_voxel(mask, i, j, k, pad):
    nx, ny, nz = mask.shape

    for di in range(-pad, pad + 1):
        for dj in range(-pad, pad + 1):
            for dk in range(-pad, pad + 1):
                ii = int(i + di)
                jj = int(j + dj)
                kk = int(k + dk)

                if 0 <= ii < nx and 0 <= jj < ny and 0 <= kk < nz:
                    mask[ii, jj, kk] = 1


def export_selected_hipsta_roi(
    obj,
    target_volume,
    output_path,
    neg_mm,
    pos_mm,
    step_mm,
    voxel_pad,
):
    nib = get_nib()

    indices = selected_vertex_indices(obj)

    if not indices:
        raise RuntimeError("No HipSTA vertices are selected.")

    anatomical_obj = _anatomical_source_object(obj)

    reference_path = Path(
        str(anatomical_obj.get("hipsta_reference_mgz", ""))
    )

    if not reference_path.is_file():
        raise RuntimeError(
            "The HipSTA reference MGZ stored on the anatomical object was "
            f"not found:\n  {reference_path}"
        )

    target_path = Path(target_volume) if target_volume else reference_path

    if not target_path.is_file():
        raise RuntimeError(
            f"Target volume was not found:\n  {target_path}"
        )

    output_path = Path(output_path)

    output_lower = output_path.name.lower()

    if not (
        output_lower.endswith(".nii")
        or output_lower.endswith(".nii.gz")
    ):
        raise RuntimeError(
            "HipSTA ROI output must end with .nii or .nii.gz."
        )

    target_image = nib.load(str(target_path))

    if len(target_image.shape) != 3:
        raise RuntimeError(
            f"Target volume must be 3D, not shape {target_image.shape}."
        )

    transform = build_tkras_to_target_vox(
        str(reference_path),
        target_image,
    )

    vertices, normals = _mesh_local_vertices_and_normals(anatomical_obj)

    if len(vertices) != len(obj.data.vertices):
        raise RuntimeError(
            "Selected and anatomical HipSTA meshes have different vertex counts."
        )

    selected_vertices = vertices[indices, :]
    selected_normals = normals[indices, :]

    neg_mm = max(0.0, float(neg_mm))
    pos_mm = max(0.0, float(pos_mm))
    step_mm = max(1e-6, float(step_mm))
    voxel_pad = max(0, int(voxel_pad))

    negative = (
        np.arange(-neg_mm, 0.0, step_mm, dtype=np.float64)
        if neg_mm > 0.0
        else np.asarray([], dtype=np.float64)
    )

    positive = (
        np.arange(step_mm, pos_mm + 1e-9, step_mm, dtype=np.float64)
        if pos_mm > 0.0
        else np.asarray([], dtype=np.float64)
    )

    offsets = np.concatenate(
        [
            negative,
            np.asarray([0.0], dtype=np.float64),
            positive,
        ]
    )

    mask = np.zeros(target_image.shape, dtype=np.uint8)

    for distance in offsets:
        points = selected_vertices + (selected_normals * float(distance))

        homogeneous = np.column_stack(
            [points, np.ones(points.shape[0], dtype=np.float64)]
        )

        ijk = (transform @ homogeneous.T).T[:, :3]
        rounded = np.rint(ijk).astype(np.int64)

        for i, j, k in rounded:
            _stamp_voxel(
                mask,
                int(i),
                int(j),
                int(k),
                voxel_pad,
            )

    n_voxels = int(np.count_nonzero(mask))

    if n_voxels == 0:
        raise RuntimeError(
            "The selected HipSTA vertices mapped to zero target voxels. "
            "Check that the target volume belongs to the same subject and "
            "coordinate space."
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)

    output_image = nib.Nifti1Image(
        mask,
        np.asarray(target_image.affine, dtype=np.float64),
    )

    try:
        output_image.set_qform(target_image.affine, code=1)
        output_image.set_sform(target_image.affine, code=1)
    except Exception:
        pass

    nib.save(output_image, str(output_path))

    return n_voxels, target_path, reference_path


# -------------------------------------------------------------------
# Properties
# -------------------------------------------------------------------

class HIPSTA_Props(bpy.types.PropertyGroup):
    subject_dir: bpy.props.StringProperty(
        name="HipSTA subject directory",
        subtype="DIR_PATH",
        default="",
        description=(
            "Subject-level HipSTA output directory containing lh/ and/or rh/. "
            "The parent hipsta/ directory is also accepted when it contains one subject."
        ),
    )

    hemisphere: bpy.props.EnumProperty(
        name="Hemisphere",
        items=HEMISPHERE_ITEMS,
        default="BOTH",
    )

    surface_type: bpy.props.EnumProperty(
        name="Surface",
        items=SURFACE_ITEMS,
        default="MID",
    )

    overlay_type: bpy.props.EnumProperty(
        name="Overlay",
        items=OVERLAY_ITEMS,
        default="THICKNESS",
    )

    replace_existing: bpy.props.BoolProperty(
        name="Replace matching objects",
        default=True,
        description="Replace HipSTA_lh/rh surface objects with the same name.",
    )

    smooth_shading: bpy.props.BoolProperty(
        name="Smooth shading",
        default=True,
    )

    palette: bpy.props.EnumProperty(
        name="Palette",
        items=PALETTE_ITEMS,
        default="INFERNO",
    )

    invert_palette: bpy.props.BoolProperty(
        name="Invert palette",
        default=False,
    )

    use_auto_range: bpy.props.BoolProperty(
        name="Automatic range",
        default=True,
    )

    symmetric: bpy.props.BoolProperty(
        name="Symmetric ±range",
        default=False,
        description="Useful for signed curvature measures.",
    )

    p_lo: bpy.props.FloatProperty(
        name="Low percentile",
        default=2.0,
        min=0.0,
        max=50.0,
    )

    p_hi: bpy.props.FloatProperty(
        name="High percentile",
        default=98.0,
        min=50.0,
        max=100.0,
    )

    vmin: bpy.props.FloatProperty(
        name="Minimum",
        default=0.0,
    )

    vmax: bpy.props.FloatProperty(
        name="Maximum",
        default=5.0,
    )

    last_range_min: bpy.props.FloatProperty(
        name="Last minimum",
        default=0.0,
        options={"HIDDEN"},
    )

    last_range_max: bpy.props.FloatProperty(
        name="Last maximum",
        default=1.0,
        options={"HIDDEN"},
    )

    last_status: bpy.props.StringProperty(
        name="Last status",
        default="",
        options={"HIDDEN"},
    )

    threshold_mode: bpy.props.EnumProperty(
        name="Condition",
        items=THRESHOLD_ITEMS,
        default="LESS",
    )

    threshold_value: bpy.props.FloatProperty(
        name="Threshold",
        default=2.0,
    )

    threshold_clear_existing: bpy.props.BoolProperty(
        name="Replace current selection",
        default=True,
        description=(
            "Clear all currently selected vertices before applying the new "
            "threshold mask. Disable to add threshold-matching vertices to "
            "the existing selection."
        ),
    )

    intrinsic_x_scale: bpy.props.FloatProperty(
        name="Medial–lateral scale",
        default=1.0,
        min=0.01,
        max=50.0,
        description=(
            "Display spacing for HipSTA intrinsic x-grid units. "
            "This changes only the flat visualisation."
        ),
    )

    intrinsic_y_scale: bpy.props.FloatProperty(
        name="Posterior–anterior scale",
        default=1.0,
        min=0.01,
        max=50.0,
        description=(
            "Display spacing for HipSTA intrinsic y-grid units. "
            "This changes only the flat visualisation."
        ),
    )

    intrinsic_flip_x: bpy.props.BoolProperty(
        name="Flip medial ↔ lateral",
        default=False,
        description="Reverse only the displayed intrinsic x direction.",
    )

    intrinsic_flip_y: bpy.props.BoolProperty(
        name="Flip posterior ↔ anterior",
        default=False,
        description="Reverse only the displayed intrinsic y direction.",
    )

    intrinsic_coordinate_tolerance: bpy.props.FloatProperty(
        name="VTK/CSV tolerance",
        default=0.001,
        min=0.000001,
        max=1.0,
        precision=6,
        description=(
            "Maximum coordinate difference allowed when validating that the "
            "HipSTA surface CSV belongs to the loaded VTK surface."
        ),
    )

    flatten_offset_x: bpy.props.FloatProperty(
        name="Display X offset",
        default=60.0,
        description=(
            "Move the flat selection object along Blender world X so it does "
            "not overlap the anatomical mesh."
        ),
    )

    replace_flattened: bpy.props.BoolProperty(
        name="Replace matching flat mesh",
        default=True,
    )

    selected_csv_path: bpy.props.StringProperty(
        name="Selected-values CSV",
        subtype="FILE_PATH",
        default="",
        description="Leave blank to write beside the HipSTA subject outputs.",
    )

    last_selection_stats: bpy.props.StringProperty(
        name="Last selected statistics",
        default="",
        options={"HIDDEN"},
    )

    roi_target_volume: bpy.props.StringProperty(
        name="Target volume (optional)",
        subtype="FILE_PATH",
        default="",
        description=(
            "3D NIfTI/MGZ target grid. Leave blank to use the HipSTA "
            "<hemi>.image.mgz grid."
        ),
    )

    roi_output_path: bpy.props.StringProperty(
        name="Output NIfTI",
        subtype="FILE_PATH",
        default="",
        description="Leave blank to create a filename beside the HipSTA outputs.",
    )

    roi_below_mm: bpy.props.FloatProperty(
        name="Below surface (mm)",
        default=0.0,
        min=0.0,
    )

    roi_above_mm: bpy.props.FloatProperty(
        name="Above surface (mm)",
        default=0.0,
        min=0.0,
    )

    roi_step_mm: bpy.props.FloatProperty(
        name="Step (mm)",
        default=0.25,
        min=0.01,
    )

    roi_voxel_pad: bpy.props.IntProperty(
        name="Voxel pad",
        default=0,
        min=0,
        soft_max=5,
    )


# -------------------------------------------------------------------
# Operators
# -------------------------------------------------------------------

class HIPSTA_OT_Load(bpy.types.Operator):
    bl_idname = "hipsta.load_surfaces"
    bl_label = "Load HipSTA"
    bl_description = "Load HipSTA VTK surface(s) and the selected MGH overlay"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            subject_dir = resolve_subject_dir(props.subject_dir)
            hemispheres = _selected_hemispheres(props.hemisphere)

            prepared = []

            for hemi in hemispheres:
                surface_path = _surface_path(
                    subject_dir,
                    hemi,
                    props.surface_type,
                )

                points, faces = read_hipsta_vtk(surface_path)

                overlay_path = _overlay_path(
                    subject_dir,
                    hemi,
                    props.surface_type,
                    props.overlay_type,
                )

                values = (
                    load_overlay_values(overlay_path, len(points))
                    if overlay_path is not None
                    else None
                )

                reference_path = _reference_mgz(subject_dir, hemi)

                prepared.append(
                    {
                        "hemi": hemi,
                        "surface_path": surface_path,
                        "points": points,
                        "faces": faces,
                        "overlay_path": overlay_path,
                        "values": values,
                        "reference_path": reference_path,
                    }
                )

            shared_vmin = None
            shared_vmax = None

            if (
                props.overlay_type not in {"NONE", "HSF"}
                and prepared
            ):
                finite_sets = [
                    item["values"][np.isfinite(item["values"])]
                    for item in prepared
                    if item["values"] is not None
                    and np.isfinite(item["values"]).any()
                ]

                if finite_sets:
                    shared_vmin, shared_vmax = _range_from_values(
                        np.concatenate(finite_sets),
                        props,
                    )

            objects = []

            for item in prepared:
                obj = _create_surface_object(
                    context=context,
                    subject_dir=subject_dir,
                    hemi=item["hemi"],
                    surface_type=props.surface_type,
                    surface_path=item["surface_path"],
                    points=item["points"],
                    faces=item["faces"],
                    reference_path=item["reference_path"],
                    props=props,
                )

                used_vmin, used_vmax = apply_overlay_to_object(
                    obj=obj,
                    values=item["values"],
                    overlay_type=props.overlay_type,
                    overlay_path=item["overlay_path"],
                    props=props,
                    vmin=shared_vmin,
                    vmax=shared_vmax,
                )

                props.last_range_min = float(used_vmin)
                props.last_range_max = float(used_vmax)

                objects.append(obj)

            _activate_objects(context, objects)

            props.subject_dir = str(subject_dir)
            props.last_status = (
                f"Loaded {len(objects)} HipSTA surface(s): "
                + ", ".join(obj.name for obj in objects)
            )

            self.report({"INFO"}, props.last_status)

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_UpdateSelected(bpy.types.Operator):
    bl_idname = "hipsta.update_selected_overlays"
    bl_label = "Update selected HipSTA objects"
    bl_description = "Apply the chosen overlay and display settings to selected HipSTA meshes"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            objects = [
                obj
                for obj in context.selected_objects
                if obj.type == "MESH"
                and bool(obj.get("hipsta_surface", False))
            ]

            if not objects:
                objects = [_active_hipsta_object(context)]

            prepared = []

            for obj in objects:
                subject_dir = Path(str(obj.get("hipsta_subject_dir", "")))
                hemi = str(obj.get("hipsta_hemi", "lh"))
                surface_type = str(obj.get("hipsta_surface_type", "mid")).upper()

                overlay_path = _overlay_path(
                    subject_dir,
                    hemi,
                    surface_type,
                    props.overlay_type,
                )

                values = (
                    load_overlay_values(
                        overlay_path,
                        len(obj.data.vertices),
                    )
                    if overlay_path is not None
                    else None
                )

                prepared.append(
                    {
                        "obj": obj,
                        "path": overlay_path,
                        "values": values,
                    }
                )

            shared_vmin = None
            shared_vmax = None

            if props.overlay_type not in {"NONE", "HSF"}:
                finite_sets = [
                    item["values"][np.isfinite(item["values"])]
                    for item in prepared
                    if item["values"] is not None
                    and np.isfinite(item["values"]).any()
                ]

                if finite_sets:
                    shared_vmin, shared_vmax = _range_from_values(
                        np.concatenate(finite_sets),
                        props,
                    )

            for item in prepared:
                used_vmin, used_vmax = apply_overlay_to_object(
                    obj=item["obj"],
                    values=item["values"],
                    overlay_type=props.overlay_type,
                    overlay_path=item["path"],
                    props=props,
                    vmin=shared_vmin,
                    vmax=shared_vmax,
                )

                props.last_range_min = float(used_vmin)
                props.last_range_max = float(used_vmax)

            props.last_status = (
                f"Updated {len(prepared)} selected HipSTA object(s)."
            )

            self.report({"INFO"}, props.last_status)

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_SelectedStats(bpy.types.Operator):
    bl_idname = "hipsta.selected_stats"
    bl_label = "Calculate selected statistics"
    bl_options = {"REGISTER"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            obj = _active_hipsta_object(context)
            overlay_type, _, values = _current_overlay_values(obj)

            indices = selected_vertex_indices(obj)

            if not indices:
                raise RuntimeError("No HipSTA vertices are selected.")

            selected = values[indices]
            selected = selected[np.isfinite(selected)]

            if selected.size == 0:
                raise RuntimeError(
                    "The selected vertices contain no finite overlay values."
                )

            if overlay_type == "HSF":
                labels, counts = np.unique(
                    np.rint(selected).astype(np.int64),
                    return_counts=True,
                )

                parts = [
                    f"{int(label)}: {int(count)}"
                    for label, count in zip(labels, counts)
                ]

                message = (
                    f"n={selected.size}; labels "
                    + ", ".join(parts)
                )

            else:
                message = (
                    f"n={selected.size}; "
                    f"mean={np.mean(selected):.6g}; "
                    f"median={np.median(selected):.6g}; "
                    f"SD={np.std(selected, ddof=1) if selected.size > 1 else 0.0:.6g}; "
                    f"min={np.min(selected):.6g}; "
                    f"max={np.max(selected):.6g}"
                )

            props.last_selection_stats = message

            self.report({"INFO"}, message)

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_ThresholdSelect(bpy.types.Operator):
    bl_idname = "hipsta.threshold_select"
    bl_label = "Select by overlay threshold"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            obj = _active_hipsta_object(context)
            _, _, values = _current_overlay_values(obj)

            threshold = float(props.threshold_value)
            mode = str(props.threshold_mode)

            if mode == "LESS":
                mask = values < threshold
            elif mode == "LESS_EQUAL":
                mask = values <= threshold
            elif mode == "GREATER":
                mask = values > threshold
            else:
                mask = values >= threshold

            mask &= np.isfinite(values)

            _set_selection(
                obj,
                mask,
                clear_existing=bool(props.threshold_clear_existing),
            )

            matching_count = int(np.count_nonzero(mask))
            final_count = len(selected_vertex_indices(obj))

            action = (
                "Replaced selection"
                if props.threshold_clear_existing
                else "Added threshold matches"
            )

            self.report(
                {"INFO"},
                f"{action} on '{obj.name}': "
                f"{matching_count} threshold-matching vertices; "
                f"{final_count} selected in total.",
            )

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_CreateFlatSelection(bpy.types.Operator):
    bl_idname = "hipsta.create_flat_selection"
    bl_label = "Create flat selection mesh"
    bl_description = (
        "Create a linked planar selection view from HipSTA intrinsic "
        "medial–lateral and posterior–anterior grid coordinates"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            active = _active_hipsta_object(context)
            source = _anatomical_source_object(active)

            flat, info = create_flat_selection_object(
                context,
                source,
                props,
            )

            _activate_objects(context, [flat])

            props.last_status = (
                f"Created {flat.name} from HipSTA intrinsic grid coordinates; "
                f"preserved {len(flat.data.vertices)} vertices and "
                f"{len(flat.data.polygons)} faces; "
                f"CSV/VTK max coordinate difference "
                f"{info['max_coordinate_error']:.3g}."
            )

            self.report({"INFO"}, props.last_status)

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_TransferSelectionToAnatomical(bpy.types.Operator):
    bl_idname = "hipsta.transfer_selection_to_anatomical"
    bl_label = "Flat → anatomical selection"
    bl_description = (
        "Transfer the current flat-mesh selection to the linked anatomical "
        "HipSTA surface by exact vertex index"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            flat = _active_hipsta_object(context)

            if not bool(flat.get("hipsta_flattened", False)):
                raise RuntimeError(
                    "The active HipSTA object is not a flat selection mesh."
                )

            # Read the Edit-mode selection before switching active objects.
            mask = _selection_mask(flat)
            anatomical = _anatomical_source_object(flat)

            if context.mode == "EDIT_MESH":
                bpy.ops.object.mode_set(mode="OBJECT")

            _set_selection(
                anatomical,
                mask,
                clear_existing=True,
            )

            _activate_objects(context, [anatomical])

            count = int(np.count_nonzero(mask))

            self.report(
                {"INFO"},
                f"Transferred {count} selected vertices to '{anatomical.name}'.",
            )

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_TransferSelectionFromAnatomical(bpy.types.Operator):
    bl_idname = "hipsta.transfer_selection_from_anatomical"
    bl_label = "Anatomical → flat selection"
    bl_description = (
        "Transfer the linked anatomical HipSTA selection back to the flat "
        "selection mesh by exact vertex index"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            flat = _active_hipsta_object(context)

            if not bool(flat.get("hipsta_flattened", False)):
                raise RuntimeError(
                    "Select the linked flat HipSTA object first."
                )

            anatomical = _anatomical_source_object(flat)
            mask = _selection_mask(anatomical)

            if context.mode == "EDIT_MESH":
                bpy.ops.object.mode_set(mode="OBJECT")

            _set_selection(
                flat,
                mask,
                clear_existing=True,
            )

            _activate_objects(context, [flat])

            count = int(np.count_nonzero(mask))

            self.report(
                {"INFO"},
                f"Transferred {count} selected vertices to '{flat.name}'.",
            )

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_ExportSelectedCSV(bpy.types.Operator):
    bl_idname = "hipsta.export_selected_csv"
    bl_label = "Export selected values to CSV"
    bl_options = {"REGISTER"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            obj = _active_hipsta_object(context)
            indices = selected_vertex_indices(obj)

            if not indices:
                raise RuntimeError("No HipSTA vertices are selected.")

            output_text = abspath(props.selected_csv_path)

            output_path = (
                Path(output_text)
                if output_text
                else _default_csv_path(obj)
            )

            if output_path.suffix.lower() != ".csv":
                output_path = output_path.with_suffix(".csv")

            output_path.parent.mkdir(parents=True, exist_ok=True)

            anatomical_obj = _anatomical_source_object(obj)

            anatomical_vertices, _ = _mesh_local_vertices_and_normals(
                anatomical_obj
            )
            displayed_vertices, _ = _mesh_local_vertices_and_normals(obj)

            if len(anatomical_vertices) != len(displayed_vertices):
                raise RuntimeError(
                    "Displayed and anatomical HipSTA vertex counts differ."
                )

            measurements = available_measurements_for_object(obj)

            current_type = str(obj.get("hipsta_overlay_type", "NONE"))
            current_values = None

            try:
                _, _, current_values = _current_overlay_values(obj)
            except Exception:
                current_values = None

            with output_path.open(
                "w",
                encoding="utf-8",
                newline="",
            ) as handle:
                writer = csv.writer(handle)

                writer.writerow(
                    [
                        "object_name",
                        "hemisphere",
                        "surface",
                        "vertex_index",
                        "x_tkras_mm",
                        "y_tkras_mm",
                        "z_tkras_mm",
                        "display_x",
                        "display_y",
                        "display_z",
                        "is_flat_selection_mesh",
                        "current_overlay",
                        "current_value",
                        "thickness_mm",
                        "subfield_label",
                        "mean_curvature",
                        "gaussian_curvature",
                    ]
                )

                for index in indices:
                    index = int(index)
                    x, y, z = anatomical_vertices[index]
                    display_x, display_y, display_z = displayed_vertices[index]

                    def value_or_blank(array):
                        if array is None:
                            return ""

                        value = float(array[index])

                        return value if np.isfinite(value) else ""

                    writer.writerow(
                        [
                            obj.name,
                            str(obj.get("hipsta_hemi", "")),
                            str(obj.get("hipsta_surface_type", "")),
                            index,
                            float(x),
                            float(y),
                            float(z),
                            float(display_x),
                            float(display_y),
                            float(display_z),
                            bool(obj.get("hipsta_flattened", False)),
                            current_type,
                            value_or_blank(current_values),
                            value_or_blank(measurements["thickness_mm"]),
                            value_or_blank(measurements["subfield_label"]),
                            value_or_blank(measurements["mean_curvature"]),
                            value_or_blank(measurements["gaussian_curvature"]),
                        ]
                    )

            props.selected_csv_path = str(output_path)

            self.report(
                {"INFO"},
                f"Exported {len(indices)} selected vertices: {output_path}",
            )

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_ExportSelectedNifti(bpy.types.Operator):
    bl_idname = "hipsta.export_selected_nifti"
    bl_label = "Selection → NIfTI ROI"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            obj = _active_hipsta_object(context)

            target_text = abspath(props.roi_target_volume)
            output_text = abspath(props.roi_output_path)

            output_path = (
                Path(output_text)
                if output_text
                else _default_roi_path(obj)
            )

            n_voxels, target_path, reference_path = export_selected_hipsta_roi(
                obj=obj,
                target_volume=target_text,
                output_path=output_path,
                neg_mm=props.roi_below_mm,
                pos_mm=props.roi_above_mm,
                step_mm=props.roi_step_mm,
                voxel_pad=props.roi_voxel_pad,
            )

            props.roi_output_path = str(output_path)

            obj["hipsta_last_roi_path"] = str(output_path)
            obj["hipsta_last_roi_voxels"] = int(n_voxels)
            obj["hipsta_last_roi_target"] = str(target_path)
            obj["hipsta_last_roi_reference"] = str(reference_path)

            self.report(
                {"INFO"},
                f"Saved HipSTA ROI with {n_voxels} voxels: {output_path}",
            )

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HIPSTA_OT_SendToLayerTools(bpy.types.Operator):
    bl_idname = "hipsta.send_to_layer_tools"
    bl_label = "Set paths in NIfTI Paint / Vertex Select"
    bl_description = (
        "Copy the active HipSTA reference and target paths into the existing "
        "NIfTI Paint and Vertex Select tabs"
    )
    bl_options = {"REGISTER"}

    def execute(self, context):
        props = context.scene.hipsta_props

        try:
            obj = _active_hipsta_object(context)

            reference = str(obj.get("hipsta_reference_mgz", ""))

            if not reference or not os.path.isfile(reference):
                raise RuntimeError(
                    "The active HipSTA object has no valid reference MGZ."
                )

            target = abspath(props.roi_target_volume) or reference

            if hasattr(context.scene, "nifti_paint_props"):
                paint = context.scene.nifti_paint_props
                paint.fs_ref_path = reference
                paint.surface_space = "FS_TKRAS"

            if hasattr(context.scene, "vertex_select_props"):
                vertex = context.scene.vertex_select_props
                vertex.roi_target_nifti = target
                vertex.roi_surface_space = "FS_TKRAS"
                vertex.roi_reference_anatomical = None
                vertex.roi_volume_method = "NORMAL"

                output_text = abspath(props.roi_output_path)

                vertex.roi_output_path = str(
                    Path(output_text)
                    if output_text
                    else _default_roi_path(obj)
                )

                vertex.sample_neg_mm = float(props.roi_below_mm)
                vertex.sample_pos_mm = float(props.roi_above_mm)
                vertex.sample_step_mm = float(props.roi_step_mm)
                vertex.voxel_pad = int(props.roi_voxel_pad)

            self.report(
                {"INFO"},
                "HipSTA reference/ROI paths copied to the Layer Tools tabs.",
            )

            return {"FINISHED"}

        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


# -------------------------------------------------------------------
# Panel
# -------------------------------------------------------------------

def _draw_wrapped_labels(layout, text, width=72, max_lines=6):
    text = str(text or "").strip()

    if not text:
        return

    remaining = text
    lines = []

    while remaining and len(lines) < max_lines:
        if len(remaining) <= width:
            lines.append(remaining)
            break

        cut = remaining.rfind(";", 0, width)

        if cut < 20:
            cut = remaining.rfind(" ", 0, width)

        if cut < 20:
            cut = width

        lines.append(remaining[:cut].strip(" ;"))
        remaining = remaining[cut:].strip(" ;")

    if remaining:
        lines.append("…")

    for line in lines:
        layout.label(text=line)


class HIPSTA_PT_Panel(bpy.types.Panel):
    bl_label = "HipSTA"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY

    def draw(self, context):
        layout = self.layout
        props = context.scene.hipsta_props

        load_box = layout.box()
        load_box.label(text="Load HipSTA surface", icon="MESH_DATA")
        load_box.prop(props, "subject_dir")
        load_box.prop(props, "hemisphere")
        load_box.prop(props, "surface_type")
        load_box.prop(props, "overlay_type")

        row = load_box.row(align=True)
        row.prop(props, "replace_existing")
        row.prop(props, "smooth_shading")

        load_box.operator(
            "hipsta.load_surfaces",
            text="Load HipSTA",
            icon="IMPORT",
        )

        display_box = layout.box()
        display_box.label(text="Overlay display", icon="BRUSH_DATA")
        display_box.prop(props, "palette")
        display_box.prop(props, "invert_palette")
        display_box.prop(props, "symmetric")
        display_box.prop(props, "use_auto_range")

        if props.use_auto_range:
            row = display_box.row(align=True)
            row.prop(props, "p_lo")
            row.prop(props, "p_hi")
        else:
            row = display_box.row(align=True)
            row.prop(props, "vmin")
            row.prop(props, "vmax")

        display_box.operator(
            "hipsta.update_selected_overlays",
            icon="FILE_REFRESH",
        )

        range_row = display_box.row()
        range_row.enabled = False
        range_row.label(
            text=(
                f"Last range: {props.last_range_min:.5g} "
                f"to {props.last_range_max:.5g}"
            )
        )

        obj = context.active_object

        if (
            obj
            and obj.type == "MESH"
            and bool(obj.get("hipsta_surface", False))
        ):
            info_box = layout.box()
            info_box.label(text="Active HipSTA mesh", icon="OBJECT_DATA")
            info_box.label(text=obj.name)
            info_box.label(
                text=(
                    f"{str(obj.get('hipsta_hemi', '')).upper()} | "
                    f"{str(obj.get('hipsta_surface_type', '')).title()} surface"
                )
            )
            info_box.label(
                text=(
                    f"{len(obj.data.vertices)} vertices | "
                    f"{len(obj.data.polygons)} faces"
                )
            )

            overlay_name = str(obj.get("hipsta_overlay_type", "NONE"))
            info_box.label(text=f"Overlay: {overlay_name}")

            if overlay_name == "HSF":
                labels = str(obj.get("hipsta_label_values", "") or "")
                info_box.label(
                    text=f"Labels present: {labels if labels else 'none'}"
                )

            coord = info_box.row()
            coord.enabled = False

            if bool(obj.get("hipsta_flattened", False)):
                source_name = str(obj.get("hipsta_source_object", ""))
                coord.label(
                    text="Display: HipSTA intrinsic grid; ROI: linked anatomical tkRAS"
                )
                info_box.label(text=f"Linked source: {source_name}")

            else:
                coord.label(text="Coordinates: HipSTA/FreeSurfer tkRAS")

            flat_box = layout.box()
            flat_box.label(text="Intrinsic flat selection view", icon="UV")

            if bool(obj.get("hipsta_flattened", False)):
                flat_box.label(text="Method: HipSTA intrinsic grid")
                flat_box.label(text="X: medial → lateral")
                flat_box.label(text="Y: posterior → anterior")

                csv_path = str(obj.get("hipsta_intrinsic_csv", "") or "")

                if csv_path:
                    flat_box.label(
                        text=f"Grid source: {Path(csv_path).name}"
                    )

                flat_box.operator(
                    "hipsta.transfer_selection_to_anatomical",
                    icon="FORWARD",
                )

                flat_box.operator(
                    "hipsta.transfer_selection_from_anatomical",
                    icon="BACK",
                )

                note = flat_box.row()
                note.enabled = False
                note.label(text="Selections map exactly by preserved vertex index.")
            else:
                method = flat_box.row()
                method.enabled = False
                method.label(text="Method: HipSTA intrinsic grid")

                axis_box = flat_box.box()
                axis_box.label(text="Parameter-space axes")
                axis_box.label(text="X: medial → lateral")
                axis_box.label(text="Y: posterior → anterior")

                row = flat_box.row(align=True)
                row.prop(props, "intrinsic_x_scale")
                row.prop(props, "intrinsic_y_scale")

                flat_box.prop(props, "intrinsic_flip_x")
                flat_box.prop(props, "intrinsic_flip_y")
                flat_box.prop(props, "flatten_offset_x")
                flat_box.prop(props, "replace_flattened")

                advanced = flat_box.column(align=True)
                advanced.prop(props, "intrinsic_coordinate_tolerance")

                flat_box.operator(
                    "hipsta.create_flat_selection",
                    text="Create intrinsic flat selection mesh",
                    icon="UV",
                )

                note = flat_box.row()
                note.enabled = False
                note.label(
                    text="All source vertices/faces are retained; no seam is cut."
                )

                note = flat_box.row()
                note.enabled = False
                note.label(
                    text="Grid geometry is for selection, not physical measurement."
                )

            selection_box = layout.box()
            selection_box.label(text="Selected vertices", icon="GROUP_VERTEX")

            selection_box.operator(
                "hipsta.selected_stats",
                icon="DRIVER_DISTANCE",
            )

            if props.last_selection_stats:
                _draw_wrapped_labels(
                    selection_box,
                    props.last_selection_stats,
                )

            selection_box.separator()
            selection_box.label(text="Threshold selection")

            row = selection_box.row(align=True)
            row.prop(props, "threshold_mode", text="")
            row.prop(props, "threshold_value")

            selection_box.prop(props, "threshold_clear_existing")
            selection_box.operator(
                "hipsta.threshold_select",
                icon="RESTRICT_SELECT_OFF",
            )

            selection_box.separator()
            selection_box.prop(props, "selected_csv_path")
            selection_box.operator(
                "hipsta.export_selected_csv",
                icon="EXPORT",
            )

            roi_box = layout.box()
            roi_box.label(text="Selection → NIfTI ROI", icon="OUTLINER_OB_VOLUME")
            roi_box.prop(props, "roi_target_volume")
            roi_box.prop(props, "roi_output_path")

            row = roi_box.row(align=True)
            row.prop(props, "roi_below_mm")
            row.prop(props, "roi_above_mm")

            row = roi_box.row(align=True)
            row.prop(props, "roi_step_mm")
            row.prop(props, "roi_voxel_pad")

            note = roi_box.row()
            note.enabled = False
            note.label(text="Blank target = HipSTA hemisphere image grid")

            roi_box.operator(
                "hipsta.export_selected_nifti",
                icon="EXPORT",
            )

            roi_box.operator(
                "hipsta.send_to_layer_tools",
                icon="LINKED",
            )

            warning = roi_box.row()
            warning.enabled = False

            if bool(obj.get("hipsta_flattened", False)):
                warning.label(
                    text="ROI uses linked anatomical coordinates, not flat display coordinates."
                )
            else:
                warning.label(
                    text="Keep anatomical object transforms at identity for ROI export."
                )

        if props.last_status:
            status_box = layout.box()
            status_box.label(text="Last action")
            _draw_wrapped_labels(
                status_box,
                props.last_status,
                max_lines=4,
            )


# -------------------------------------------------------------------
# Register / unregister
# -------------------------------------------------------------------

_CLASSES = (
    HIPSTA_Props,
    HIPSTA_OT_Load,
    HIPSTA_OT_UpdateSelected,
    HIPSTA_OT_SelectedStats,
    HIPSTA_OT_ThresholdSelect,
    HIPSTA_OT_CreateFlatSelection,
    HIPSTA_OT_TransferSelectionToAnatomical,
    HIPSTA_OT_TransferSelectionFromAnatomical,
    HIPSTA_OT_ExportSelectedCSV,
    HIPSTA_OT_ExportSelectedNifti,
    HIPSTA_OT_SendToLayerTools,
    HIPSTA_PT_Panel,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.hipsta_props = bpy.props.PointerProperty(
        type=HIPSTA_Props
    )


def unregister():
    if hasattr(bpy.types.Scene, "hipsta_props"):
        del bpy.types.Scene.hipsta_props

    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
